statisfactory 0.3.5
Added nagelR2() for calculation of Nagelkerge's / Craig & Uhler's R2
